import boto3
import json
import time
from botocore.exceptions import ClientError

def create_s3_bucket_with_policy(bucket_name, region='us-east-1'):
    s3_client = boto3.client('s3', region_name=region)

    # Create S3 bucket
    try:
        s3_client.create_bucket(
            Bucket=bucket_name,
            ACL='private',  # You can set the desired ACL
        )
        print(f"S3 bucket '{bucket_name}' created successfully.")
    except Exception as e:
        print(f"Error creating S3 bucket: {e}")
        return

def read_file_content(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def create_website_folders(bucket_name, website_data):
    s3_client = boto3.client('s3')

    try:
        for folder, file_path in website_data.items():
            # Create folder for each website
            folder_key = f"{folder}/"
            s3_client.put_object(Bucket=bucket_name, Key=folder_key)

            # Read the content of the index.html file from the specified path
            content = read_file_content(file_path)

            # Put an index.html file in each folder with the content read from the file
            s3_client.put_object(Bucket=bucket_name, Key=f"{folder_key}index.html", Body=content, ContentType='text/html')

        print(f"Website folders and index.html files created successfully in bucket '{bucket_name}'.")
    except ClientError as e:
        print(f"Error creating website folders and index.html files: {e}")

def create_cloudfront_oai():
    cloudfront = boto3.client('cloudfront')
    response = cloudfront.create_cloud_front_origin_access_identity(
        CloudFrontOriginAccessIdentityConfig={
            'CallerReference': str(int(time.time())),
            'Comment': 'New.s3.oai'
        }
    )

    oai_id = response['CloudFrontOriginAccessIdentity']['Id']
    print(f"CloudFront OAI created with ID: {oai_id}")

    return oai_id

def create_cloudfront_distribution(bucket_name, domain_names, ssl_certificate_arn, lambda_function_arn):
    # Create CloudFront Origin Access Identity (OAI)
    oai_id = create_cloudfront_oai()
    cloudfront = boto3.client('cloudfront')

    # Create CloudFront distribution configuration
    distribution_config = {
        'CallerReference': str(int(time.time())),
        'Comment': 'Custom CloudFront Distribution',
        'DefaultRootObject': '/index.html',
        'Enabled': True,
        'Origins': {
            'Quantity': 1,
            'Items': [
                {
                    'Id': f'S3-{bucket_name}',
                    'DomainName': f'{bucket_name}.s3.amazonaws.com',
                    'S3OriginConfig': {
                        'OriginAccessIdentity': f'origin-access-identity/cloudfront/{oai_id}'
                    }
                },
            ]
        },
        'DefaultCacheBehavior': {
            'LambdaFunctionAssociations': {
                'Quantity': 1,
                'Items': [
                    {
                        'LambdaFunctionARN': lambda_function_arn,
                        'EventType': 'origin-request'
                    },
                ]
            },
            'TargetOriginId': f'S3-{bucket_name}',
            'ForwardedValues': {
                'QueryString': False,
                'Cookies': {'Forward': 'none'},
                'Headers': {
                    'Quantity': 1,
                    'Items': ['Host']
                }
            },
            'ViewerProtocolPolicy': 'redirect-to-https',
            'MinTTL': 0,
            'AllowedMethods': {
                'Quantity': 2,
                'Items': ['GET', 'HEAD']
            }
        },
        'PriceClass': 'PriceClass_100',
        'ViewerCertificate': {
            'CloudFrontDefaultCertificate': False,
            'ACMCertificateArn': ssl_certificate_arn,
            'SSLSupportMethod': 'sni-only',
            'MinimumProtocolVersion': 'TLSv1.2_2021',
        },
        'CustomErrorResponses': {
            'Quantity': 1,
            'Items': [
                {
                    'ErrorCode': 403,
                    'ResponsePagePath': '/index.html',
                    'ResponseCode': '200',
                    'ErrorCachingMinTTL': 0
                },
            ]
        },
        'Aliases': {
            'Quantity': len(domain_names),
            'Items': domain_names
        },
        'Origins': {
            'Quantity': 1,
            'Items': [
                {
                    'Id': f'S3-{bucket_name}',
                    'DomainName': f'{bucket_name}.s3.amazonaws.com',
                    'S3OriginConfig': {
                        'OriginAccessIdentity': f'origin-access-identity/cloudfront/{oai_id}'
                    }
                }
            ]
        },
    }

    # Create CloudFront distribution
    response = cloudfront.create_distribution(DistributionConfig=distribution_config)

    # Get the distribution ID
    distribution_id = response['Distribution']['Id']
    print(f"CloudFront distribution created with ID: {distribution_id}")

    # Get CloudFront domain name
    distribution_info = cloudfront.get_distribution(Id=distribution_id)
    cloudfront_domain_name = distribution_info['Distribution']['DomainName']

    print(f"CloudFront Domain Name: {cloudfront_domain_name}")

if __name__ == "__main__":
    # Replace these values with your specific details
    bucket_name = 'madhu-multi-site'
    domain_names = ['site1.sachaikarakhwala.online', 'site2.sachaikarakhwala.online', 'site3.sachaikarakhwala.online', 'sachaikarakhwala.online']
    ssl_certificate_arn = 'arn:aws:acm:us-east-1:445097818131:certificate/4133dc38-baf5-4cf6-8b4d-5d3eed25a3c6'
    lambda_function_arn = 'arn:aws:lambda:us-east-1:445097818131:function:madhu-multi-site:1'

    # Create S3 bucket with policy
    create_s3_bucket_with_policy(bucket_name)

    # Example data for folder names and file paths
    website_data = {
        'site1.sachaikarakhwala.online': '/root/f1/index.html',
        'site2.sachaikarakhwala.online': '/root/f2/index.html',
        'site3.sachaikarakhwala.online': '/root/f3/index.html',
    }

    # Call the function to create website folders and index.html files
    create_website_folders(bucket_name, website_data)

    # Create CloudFront distribution with OAI and update S3 bucket policy
    create_cloudfront_distribution(bucket_name, domain_names, ssl_certificate_arn, lambda_function_arn)